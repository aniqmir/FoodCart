import React, { Component } from 'react';
import CustomeRoutes from './Routes/Routes.jsx';

class App extends Component {
  render() {
    return (
      <div className="App">
        <CustomeRoutes/>
      </div>
    );
  }
}

export default App;
